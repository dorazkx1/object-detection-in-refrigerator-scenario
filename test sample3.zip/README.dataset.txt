# Fridge object detection > 2025-07-08 7:44pm
https://universe.roboflow.com/computer-vision-flc0t/fridge-object-detection-ekeza

Provided by a Roboflow user
License: CC BY 4.0

